<?php

namespace routes;

use controllers\Account;
use controllers\Main;
use controllers\VideoWeb;
use routes\base\Route;


class Web
{
    function __construct()
    {
        $videoWeb = new VideoWeb();
        $main = new Main();
        $account = new Account();
      
	

        Route::Add('/', [$videoWeb, 'home']);
        Route::Add('/about', [$main, 'about']);
        Route::Add('/login', [$account, 'login']);
		Route::Add('/ping', [$main, 'ping']);
	
        Route::Add('/me', [$account, 'me']);
        Route::Add('/logout', [$account, 'logout']);

      
        
    }
}

