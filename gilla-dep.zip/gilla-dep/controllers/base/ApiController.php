<?php

namespace controllers\base;

class ApiController implements IBase
{
    function redirect($to)
    {
        // Do Nothing
    }
}