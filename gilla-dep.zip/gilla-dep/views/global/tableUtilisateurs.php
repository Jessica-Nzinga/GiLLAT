<h1>PONG</h1>
<?php
        foreach ($users as $user) {
 ?>
  <br />
            <?= $user->nom ?></a>
<?php
		}                   

 ?>       
